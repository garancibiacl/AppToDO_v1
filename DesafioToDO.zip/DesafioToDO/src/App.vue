<template>
  <div>
    <ToDo></ToDo>
  </div>
</template>

// Se importa componente
<script>
import ToDo from "./components/ToDo.vue";
export default {
  components: { ToDo },
};
</script>

<style>
</style>
